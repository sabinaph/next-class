-- AlterTable
ALTER TABLE "users" ADD COLUMN     "createdBy" TEXT;
